//Use strict command.

"use strict";

//Define the function $ to return the id of an element.

var $ = function (id) { return document.getElementById(id);};

//Define the function calculateChange to calculate the

//number of quarters, dimes, nickels, and pennies.

var calculateChange = function() {



    //Declare the required variables.

    var cents, quarters, dimes, nickels, pennies;

    //Get the number of cents from the user.

    coins.cents = Math.floor(parseInt($("cents").value));

    //If the function isValid of object coin returns false,

    //then display an alert message.

    if (coins.isValid() == false)

    {

        //Display an appropriate message.

        alert("Please enter a valid number between 0 and 99");

    }

    //Else part.

    else

    {



        //Calculate the number of quarters.

        quarters = coins.getNumber(25);

        //Calculate the number of dimes.

        dimes = coins.getNumber(10);

        //Calculate the number of nickels.

        nickels = coins.getNumber(5);

        //Calculate the number of pennies.

        pennies = coins.cents % 5;

        //Display the results of the calculations.

        $("quarters").value = quarters;

        $("dimes").value = dimes;

        $("nickels").value = nickels;

        $("pennies").value = pennies;

    }

};

//Define the function onload.

window.onload = function () {

    $("calculate").onclick = calculateChange;

    $("cents").focus();

};