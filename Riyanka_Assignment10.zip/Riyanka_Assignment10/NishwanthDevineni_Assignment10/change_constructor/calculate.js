var $ = function (id) {

    return document.getElementById(id);

};

var calculateChange = function() {

    var cents, quarters, dimes, nickels, pennies;



    // get the number of cents from the user

    cents = Math.floor(parseInt($("cents").value));



    var cents = new coins(cents);

    if (!cents.isValid()) {

        alert("Please enter a valid number between 0 and 99");

    } else {

        // calculate the number of quarters

        quarters = cents.getNumber(25); // get number of quarters

        // calculate the number of dimes

        dimes = cents.getNumber(10); // get number of dimes

        // calculate the number of nickels

        nickels = cents.getNumber(5);

        // calculate the number of nickels and pennies

        pennies = cents.getNumber(1);

        // display the results of the calculations

        $("quarters").value = quarters;

        $("dimes").value = dimes;

        $("nickels").value = nickels;

        $("pennies").value = pennies;

    }

};

window.onload = function () {

    $("calculate").onclick = calculateChange;

    $("cents").focus();

};